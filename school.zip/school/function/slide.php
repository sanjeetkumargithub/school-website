function img(){
<html>
<head>
<title>Home page School</title>
<link type="text/css" rel="stylesheet" href="function/slide_style.css"/> 
</head>
<body
<div id="center_content1">
<div id="center_content">
			<img src="image/img1.jpg"/ width="570px"height="300px ">
			<img src="image/img2.jpg"/ width="570px"height="300px ">
			<img src="image/img3.jpg"/ width="570px"height="300px ">
			<img src="image/img4.jpg"/ width="570px"height="300px ">
			<img src="image/img5.jpg"/ width="570px"height="300px "></div>

</div>
</body>
</html>
}