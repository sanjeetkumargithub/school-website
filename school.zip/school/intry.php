
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home page School</title>
<link type="text/css" rel="stylesheet" href="css_style/style.css"/> 
<script  type="text/javascript"src='C:\Users\sanjeetku\Documents\jquery1.js'></script>
	<script >
	</script>
	<style>
	a
	{
		text-decoration:none;
		color:white;
	}
	
	
	#about{
	
					float:left;
					width:210px;
					height:1235px;
					background-color:white;}
		#abo1 	
			ul li{
			both:clear;
			list-style:none;
			width:200px;
			height:30px;
			background:#FF6699;
			padding-top:15px;
			margin-top:3px;
			text-align:left;
			padding-left:10px;
		
			}
			#abo1 ul li a{
			text-decoration:none;
		}
			#abo1 ul li:hover{
			color:#CC3300;
			text-align:center;
			
			background-color:#CC0000;
			font-size:17px;
						width:200px;
			height:30px;
			}
		
							
	
	</style>
</head>

<body>
<!--Wrapper start-->
<div id="wrapper"> 
<!--Header start-->
<div id="header">
		<div><img src="image/th (5).jpg" height="150px" width="150px"/>
        
        <h2 class="head"> New College Muzaffarpur, </h2> 
        <h2 style="padding-left:100px; color:white;">NAAC Grade 'A'</h2>
		<h3 style="padding-left:730px;"> <a href="index.php" style="color:white; text-decoration:none;">Home</a>
		<a href="http://www.mapsofindia.com/maps/bihar/districts/muzaffarpur.htm" style="color:white; text-decoration:none;padding-left:7px; ">Map </a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Alumni</a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Download</a></h3>
        <b style="padding-left:0px; color:white;"> Under B. R. A Bihar Univesity Muzaffarpur </b>
        </div>
						

 </div><!--Header End-->
 
 
<!--Menu start-->

<?php include('menu.php'); ?>
<!--Menu End-->

<!--left content tage-->
<div id="about">
				<div id="abo1"> 
						<ul> 
                        	<li><a href="library.php">LIBRARY</a></li>
                    		<li><a href="sports.php"> SPORTS</a></li>
                    		<li ><a href="remedial.php" >REMEDIAL COACHING</a></li>
                    		<li><a href="intry.php">ENTRY IN SERVICES</a></li>
                    		<li><a href="itinfra.php">IT INFRA STRUCTURE</a></li>
                    		<li><a href="canteen.php"> CANTEEN</a></li>
                    		<li><a href="#">COMMON ROOM</a></li>              
                        </ul>




				</div>
</div>
<!--left content tage-->

<div style="width:790px;height:1235px; float:left;">
		<h3 style="background:#999999; text-decoration:underline; color:#CC0000;  width:790px; text-align:left;height:40px;padding-top:10px;">				 		COACHING FOR ENTRY IN SERVICES FOR ST/SC MINORITIES STUDENTS,</h3>
		<img src="image/entry1.jpg"/ width="790px"height="299px ">
		
		<img src="image/entry2.jpg"/ width="790px"height="299px ">
		
		<img src="image/entry3.jpg"/ width="790px"height="299px ">
		<img src="image/entry4.jpg"/ width="790px"height="299px ">
			

</div>
<!--center tage start-->



<!-- content tage end-->




<!--Footer start-->

<div id="footer"> 

		<div id="foot1">

			<h3 style="text-align:left; color:#FFFFFF; padding-left:5px;"> All Rights Reserved with New College,<b style="padding-left:280px;">
			 Design & Developed By:</b> <b id="sanjeet"> Sanjeet Kumar </b></h3>


		</div>


</div><!--Footer End-->
</div>
<!--Wrapper End-->


</body>
</html>