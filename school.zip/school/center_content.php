
<div id="center_content1">
        <div id="center_content">
			<img src="image/img1.jpg"/ width="570px"height="300px ">
			<img src="image/img2.jpg"/ width="570px"height="300px ">
			<img src="image/img3.jpg"/ width="570px"height="300px ">
			<img src="image/img4.jpg"/ width="570px"height="300px ">
			<img src="image/img5.jpg"/ width="570px"height="300px ">
			</div>	
			<div id="news">  <marquee><h3 > Graduation  Results  &nbsp;&nbsp; <b class="news_style"> News</b>  2017  &nbsp;&nbsp;  And Intermediats Results  So, Thanks on <b class="news_style"> News</b>&nbsp; 2017</h3>
			 </marquee> </div>
				<p style="color:#FFFFFF;font-size:25px; margin-top:345px;text-align:center;widht:570px; background-color:#CC0000;"> New College,</p>
			<div id="center_ictroduction" style="text-align:left;font-size:20px;">New college is Must be Facilites so my name is sanjeet kumar
			my father name is bachchulal bhagat Mother name is santi devi i have two brother and two sister
			my father is a shopkeer and mother is a housewife
			i have letest qualification bca,
			</div>




</div> 

