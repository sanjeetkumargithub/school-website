<?php
session_start();
session_destroy();

echo "<script>alert('Your Email has been LogOut')</script>";

echo "<script>window.open('index.php','_self') </script>";

?>