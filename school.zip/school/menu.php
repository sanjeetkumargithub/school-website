
<div id="menu"> 
	<div id="menu_fir" >	
    		
                    
                    
                    <ul>
                    <li><a href="#">ABOUT US</a>
                    	<ul> 
                        	<li><a href="about.php">ABOUT THE SCHOOL</a></li>
                    		<li><a href="principal.php"> PRINCIPAL'S DESC</a></li>
                    		<li ><a href="history.php" >HISTORY</a> &nbsp; &nbsp;  </li>
                    		<li><a href="vision.php">VISION</a>  &nbsp; &nbsp; </li>
                    		<li><a href="mission.php">MISSION</a></li>
                        </ul>
                    
                    </li>
					
                    <li ><a href="#" >STUDENTS ZONE</a>
                    	<ul> 
                        	<li><a href="st_admission.php">ADMISSION</a></li>
                    		<li><a href="st_exam.php"> EXAMINATION</a></li>
                    		<li ><a href="st_result.php" >RESULT</a></li>
							<li ><a href="st_activites.php" >STUDENT ACTIVITES</a></li>
                    		<li><a href="st_placement.php">PLACEMENT</a></li>
                        </ul>
                    </li>
							
                    <li><a href="#">ACEDMIC</a>
                    	<ul> 
                        	<li><a href="teachingstaff.php">TEACHING STAFF</a></li>
                    		<li><a href="research_pro.php"> RESEARCH PROJECTS</a></li>
                    		<li ><a href="research_gui.php" >RESEARCH GUIDANCE</a></li>
                    		<li><a href="non_teachingstaff.php">NON TEACHING STAFF</a></li>
                        </ul>
                    </li>
					
				</ul>	
				<!--second menu-->	
					
		<div id="menu_fir2">
					
					<ul>
					
							 <li><a href="#">ASSOCIATION</a>
                    	<ul> 
                        	<li><a href="iquac.php">IQUAC</a></li>
                    		<li><a href="#sale_purchase.php"> SALE PURCHASE COMMITEE</a></li>
                    		<li ><a href="building.php" >BUILDING DEVELOPMENT</a></li>
                    		<li><a href="commitee.php">COMMITEE</a></li>
                    		<li><a href="ad_commite.php">ADMISSION COMMITEE</a></li>
                    		<li><a href="vocational_edu.php"> VOCATIONAL EDUCATION</a></li>
                    		<li><a href="advisory.php">ADVISORY COMMITEE</a></li>              
                    		<li><a href="exetension.php">EXETENSION ACTIVITIES CELL</a></li>
                            
                    		<li><a href="research_commitee.php">RESEARCH COMMITEE</a></li>
                    		<li><a href="library_advisory.php"> LIBRARY ADVISORY COMMITEE</a></li>
                    		<li><a href="career.php">CAREER & COUNSELLING CELL</a></li>              
                    		<li><a href="rti_com.php">RTI COMMITEE</a></li>
                            
                    		<li><a href="proctorial.php">PROCTORIAL BOARD</a></li>
                        </ul>
                    </li>
                   
					</ul>
		</div>
	<div id="menu_fir1" >	
    		
                    
                    
                    <ul>	
					
                    <li><a href="#">FACILITES</a>
                    
                    
                    	<ul> 
                        	<li><a href="library.php">LIBRARY</a></li>
                    		<li><a href="sports.php"> SPORTS</a></li>
                    		<li ><a href="remedial.php" >REMEDIAL COACHING</a></li>
                    		<li><a href="intry.php">INTRY IN SERVICES</a></li>
                    		<li><a href="itinfra.php">IT INFRA STRUCTURE</a></li>
                    		<li><a href="canteen.php"> CANTEEN</a></li>
                    		<li><a href="#">COMMON ROOM</a></li>              
                        </ul> </li>
                    
                    <li><a href="#"> COURSE</a>
                    	 <ul>   
                    		<li><a href="post_graduate.php"> POST GRADUATE</a></li>
                    		<li ><a href="vocational.php" >VOCATIONAL</a></li>
                    		<li><a href="under_graduate.php">UNDER GRADUATE</a></li>
                    		<li><a href="#">SERTIFICATE/ADD-ON</a></li>
                    		<li><a href="#"> COMMUNITY COLLEGE</a></li>
                        </ul>
                    </li>
                    <li><a href="galary.php">GALLERY</a>
                    	
                    </li>
                    <li><a href="tender.php">TENDER</a>
                    
                    </li>              
                    <li><a href="contectus.php">CONTACT US</a></li>
                     
                </ul> 
    </div>

</div>
