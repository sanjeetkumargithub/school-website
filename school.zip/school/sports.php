
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home page School</title>
<link type="text/css" rel="stylesheet" href="css_style/style.css"/> 
<script  type="text/javascript"src='C:\Users\sanjeetku\Documents\jquery1.js'></script>
	<script >
	</script>
	<style>
	a
	{
		text-decoration:none;
		color:white;
	}
	
	
	#about{
	
					float:left;
					width:210px;
					height:1100px;
					background-color:white;}
		#abo1 	
			ul li{
			both:clear;
			list-style:none;
			width:200px;
			height:30px;
			background:#FF6699;
			padding-top:15px;
			margin-top:3px;
			text-align:left;
			padding-left:10px;
		
			}
			#abo1 ul li a{
			text-decoration:none;
		}
			#abo1 ul li:hover{
			color:#CC3300;
			text-align:center;
			
			background-color:#CC0000;
			font-size:17px;
						width:200px;
			height:30px;
			}
		
							
	
	</style>
</head>

<body>
<!--Wrapper start-->
<div id="wrapper"> 
<!--Header start-->
<div id="header">
		<div><img src="image/th (5).jpg" height="150px" width="150px"/>
        
        <h2 class="head"> New College Muzaffarpur, </h2> 
        <h2 style="padding-left:100px; color:white;">NAAC Grade 'A'</h2>
		<h3 style="padding-left:730px;"> <a href="index.php" style="color:white; text-decoration:none;">Home</a>
		<a href="http://www.mapsofindia.com/maps/bihar/districts/muzaffarpur.htm" style="color:white; text-decoration:none;padding-left:7px; ">Map </a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Alumni</a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Download</a></h3>
        <b style="padding-left:0px; color:white;"> Under B. R. A Bihar Univesity Muzaffarpur </b>
        </div>
						

 </div><!--Header End-->
 
 
<!--Menu start-->

<?php include('menu.php'); ?>
<!--Menu End-->

<!--left content tage-->
<div id="about">
				<div id="abo1"> 
						<ul> 
                        	<li><a href="library.php">LIBRARY</a></li>
                    		<li><a href="sports.php"> SPORTS</a></li>
                    		<li ><a href="remedial.php" >REMEDIAL COACHING</a></li>
                    		<li><a href="intry.php">INTRY IN SERVICES</a></li>
                    		<li><a href="itinfra.php">IT INFRA STRUCTURE</a></li>
                    		<li><a href="canteen.php"> CANTEEN</a></li>
                    		<li><a href="#">COMMON ROOM</a></li>              
                        </ul>

						


				</div>
</div>
<!--left content tage-->

<div style="width:790px;height:1100px; float:left;">
		<h3 style="background:#999999; text-decoration:underline; color:#CC0000;  width:790px; text-align:left;height:40px;padding-top:10px;">				 		SPORTS & GAME</h3>
		<img src="image/sports1.jpg"/ width="790px"height="299px ">
			<div style=" border:3px solid #000000; width:785px;height:780px; "> 


			SPORTS

The College has adequate facilities for Extracurricular activities and sports. There are two big play grounds are available in the College.<br/>

The College has facilities for giving training to students in the following sports and games:<hr/>
Volley ball<br/>
Badminton<br/>
Kabaddi<br/>
Cricket<br/>
Football<br/>
Basket Ball<br/>
Hockey<br/>
Table-tennis<br/>
Chess<hr/>
R.D.S. College, Muzaffarpur has been the winner & runner in different activity. Sports council of the college has produced many outdoor and indoor players, and this tradition is still maintained.<br/>

BADMINTON:<hr/>
In the past three years, the college has been the university champion in Badminton. Our two players have represented the Inter University East zone in 2008, and remained runner. While in 2009, winner of the same East zone Inter University and later in 2010, our players have represented University team as well and has qualified for the All India Inter University.<br/>

CHESS:<br/>
The college has been winner and runner during the past years of 2008, 2009 and 2010. Our three players were selected by the University for the North-East Zone in 2008 and 2009. In 2010, our three players were selected for the North-East zone and qualified for All India Inter University and they were the first five of the winners.

CRICKET: <br/>
The college has been the university champion during 2007,2008 and 2009. Our six players in 2008, seven players in 2009, and two players in 2010 represented Inter University.
TABLE-TENNIS:
Our two players represent Inter University in 2008, 2009 and 2010, as well as State University.

HOCKEY:<br/>
Our ten players selected were for Inter University in 2010.
KABADDI:<br/>

Our three players in 2008 & 2009 and two players in 2010 represented Inter University
VOLLEYBALL:<br/>
Our one player represented Inter University in 2010.
BASKETBALL:
Our two players in 2008, two players in 2009 and 2010. The college has a sports council monitoring both indoor and outdoor games. It was set up in 1948. However it has lack of indoor stadium of its own. Indoor events like Badminton, Table-tennis, Carom, Chess, are held in the auditorium viewers gallery while it’s stage is being used as practice area for Table-tennis. Actually, the auditorium is used frequently during examination; hence the regular sports activities are at stake. Therefore, the objective of Indoor stadium in the college is essential for the students participation to faster in providing the youth with a positive and healthy channelization of their abundant energy to take their place as a future leaders of the Country in myriad spheres of activity.

For outdoor games, such as Cricket, Football, Volleyball, Basketball, Tennis court and Athletic events are held in the playground that is square- shaped much larger than needed. It is significant to note that the college has not yet received any sufficient financial grant for the maintenance of the large playground from any central agencies such as UGC, CSIR DST & university till date.

The college has lack of race tracks, Basketball, Tennis court, Cricket pitch and level or even playground. The college playground is so spacious that any major tournament events can be organized and executed.
The PTI of Ramdayalu Singh College, Muzaffarpur is Mr. R Sankar Kumar.

	</div>
</div>

<!--center tage start-->



<!-- content tage end-->




<!--Footer start-->

<div id="footer"> 

		<div id="foot1">

			<h3 style="text-align:left; color:#FFFFFF; padding-left:5px;"> All Rights Reserved with New College,<b style="padding-left:280px;">
			 Design & Developed By:</b> <b id="sanjeet"> Sanjeet Kumar </b></h3>


		</div>


</div><!--Footer End-->
</div>
<!--Wrapper End-->


</body>
</html>