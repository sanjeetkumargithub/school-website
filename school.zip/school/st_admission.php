
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home page School</title>
<link type="text/css" rel="stylesheet" href="css_style/style.css"/> 
<script  type="text/javascript"src='C:\Users\sanjeetku\Documents\jquery1.js'></script>
	<script >
	</script>
	<style>
	a
	{
		text-decoration:none;
		color:white;
	}
	#about{
	
					float:left;
					width:210px;
					height:750px;
					background-color:white;}
		#abo1 	
			ul li{
			both:clear;
			list-style:none;
			width:200px;
			height:30px;
			background:#FF6699;
			padding-top:15px;
			margin-top:3px;
			text-align:left;
			padding-left:10px;
		
			}
			#abo1 ul li a{
			text-decoration:none;
		}
			#abo1 ul li:hover{
			color:#CC3300;
			text-align:center;
			
			background-color:#CC0000;
			font-size:17px;
						width:200px;
			height:30px;
			}
		
	
	</style>
</head>

<body>
<!--Wrapper start-->
<div id="wrapper"> 
<!--Header start-->
<div id="header">
		<div><img src="image/th (5).jpg" height="150px" width="150px"/>
        
        <h2 class="head"> New College Muzaffarpur, </h2> 
        <h2 style="padding-left:100px; color:white;">NAAC Grade 'A'</h2>
		<h3 style="padding-left:730px;"> <a href="index.php" style="color:white; text-decoration:none;">Home</a>
		<a href="http://www.mapsofindia.com/maps/bihar/districts/muzaffarpur.htm" style="color:white; text-decoration:none;padding-left:7px; ">Map </a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Alumni</a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Download</a></h3>
        <b style="padding-left:0px; color:white;"> Under B. R. A Bihar Univesity Muzaffarpur </b>
        </div>
						
<!--right content start-->
		
		
	<?php include('right_content.php');?>	
							
<!--right content End-->

 </div><!--Header End-->
 
 
<!--Menu start-->

<?php
include('menu.php');
?>
<!--Menu End-->

<!--left content tage-->
<div id="about">
				<div id="abo1"> 
						<ul> 
                        	<li><a href="st_admission.php">ADMISSION</a></li>
                    		<li><a href="st_exam.php"> EXAMINATION</a></li>
                    		<li ><a href="st_result.php" >RESULT</a></li>
							<li ><a href="st_activites.php" >STUDENT ACTIVITES</a></li>
                    		<li><a href="st_placement.php">PLACEMENT</a></li>
                        </ul>




				</div>
				<DIV style="padding-top:15px; height:40px;background-color:#FF00CC;color:#FF9900; margin-top:50px;">	STUDENT ADMISSION </DIV>
</div>
<!--left content tage-->
<!--center content start-->
<div id="center_content1">
<DIV style="padding-top:15px; height:40px;background-color:#FFCC99; color:white; margin-top:0px;">	STUDENT ADMISSION </DIV>
NEW ABC Singh College, one of the oldest constituent college of the then Bihar University, Muzaffarpur(at present B. R. Ambedkar Bihar University) runs MA, M.Sc. & M. Com, BA, BSc, a& B. Com. The College also runs Industrial Fish & Fisheries, Industrial Chemistry, Bachelor of Computer Application, Bachelor of Business Administration, Remedial Coaching classes and Entry in Service courses.

We endeavour to ensure that the mosaic of our student body reflects the variety and diversity that comprise the richness and greatness of our nation. This is attained by a fair and transparent Admission Procedure, driven entirely by inter se merit.

Each student seeking admission in the College has to accept the condition that the College reserves the right to deny admission to any student without assigning any reason whatsoever.

The admission to various under-graduate courses will be subjected to the number of seats available and will be done on the basis of cut off list and eligibility criteria which will be displayed on the college Notice Board as per the admission schedule. The applicant should satisfy himself/herself regarding fulfilling the criteria in every respect. Students who fulfill the eligibility criteria can seek admission as per the admission schedule.

Advertisements are being given in regional national daily newspapers. Students can apply for any course of their choice and based on their qualification. The application forms and prospects are being made available at a normal cost to the applicant.

Admission to various courses are based on merit in the past qualified examination. A college level admission committee, constituted by the college, monitors the whole admission process. A minimum of 50 % marks for the Science & Arts faculty and 60% marks for Commerce faculty in the General category, with relaxation SCST candidates. For professional and vocational courses entrance examinations are being conducted.
</div><!--center content end-->

<!--this content is wright in header bar , so top page h4 tage-->

<!--right content End-->
<!--Footer start-->

<div id="footer"> 

		<div id="foot1">

			<h3 style="text-align:left; color:#FFFFFF; padding-left:5px;"> All Rights Reserved with New College,<b style="padding-left:280px;">
			 Design & Developed By:</b> <b id="sanjeet"> Sanjeet Kumar </b></h3>


		</div>


</div><!--Footer End-->
</div>
<!--Wrapper End-->


</body>
</html>