<?php
session_start();

?>  
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home page School</title>
<link type="text/css" rel="stylesheet" href="css_style/style.css"/> 
<script  type="text/javascript"src='C:\Users\sanjeetku\Documents\jquery1.js'></script>
	<script >
	</script>
	<style>
	a
	{
		text-decoration:none;
		color:white;
	}
	
	</style>
</head>

<body>
<!--Wrapper start-->
<div id="wrapper"> 
<!--Header start-->
<div id="header">
		<div><img src="image/th (5).jpg" height="150px" width="150px"/>
        
        <h2 class="head"> New College Muzaffarpur, </h2> 
        <h2 style="padding-left:100px; color:white;">NAAC Grade 'A'</h2>
		<h3 style="padding-left:700px;"> <a href="index.php" style="color:white; text-decoration:none; border-right:3px solid #FFFFFF;">Home </a>
		<a href="http://www.mapsofindia.com/maps/bihar/districts/muzaffarpur.htm" style="color:white; text-decoration:none;padding-left:7px; border-right:3px solid #FFFFFF;">Map </a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;border-right:3px solid #FFFFFF; " >Alumni </a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Download</a></h3>
        <b style="padding-left:0px; color:white;"> Under B. R. A Bihar Univesity Muzaffarpur </b>
		<br /><b style="padding-left:380px;color:#FF3399;"> <?php if(isset($_SESSION['email'])){
		echo "Email Id No:&nbsp;&nbsp;&nbsp;".$_SESSION['email']; ?>
		<b style="padding-left:70px; font-size:15px;color:;" class="head" ><a href="sessionof.php" style="color:#FF3333;" > Email LogOut</a> </b> <?php }
		else {
		
		echo "
		 Welcome Sir,
		";
		}
		
		
		
		
		 ?> </b>
        </div>
						
<!--right content start-->
		
		
	<?php include('right_content.php');?>	
							
<!--right content End-->

 </div><!--Header End-->
 
 
<!--Menu start-->

<?php
include('menu.php');
?>
<!--Menu End-->
<!--left content Start-->


<?php include('left_content.php'); ?>

<!--left content End-->


<!--center content start-->
<?php include('center_content.php'); ?>

<!--center content end-->

<!--right content start-->

<!--this content is wright in header bar , so top page h4 tage-->

<!--right content End-->
<!--Footer start-->

<div id="footer"> 

		<div id="foot1">

			<h3 style="text-align:left; color:#FFFFFF; padding-left:5px;"> All Rights Reserved with New College,<b style="padding-left:280px;">
			 Design & Developed By:</b> <b id="sanjeet"> Sanjeet Kumar </b></h3>


		</div>


</div><!--Footer End-->
</div>
<!--Wrapper End-->


</body>
</html>