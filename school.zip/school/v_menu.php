
				<div id="abo1"> 
						
											<ul> 
                        	<li><a href="#"> POST GRADUATE</a>
                            	<ul>
                            <li><a href="hscience.php">Home Science</a></li>
                    		<li><a href="english.php"> English</a></li>
                    		<li ><a href="hindi.php" >Hindi</a></li>
                    		<li><a href="geography.php">Geography</a></li>
                    		<li><a href="psychlogy.php">Psychlogy</a></li>
                    		<li><a href="computer.php"> computer</a></li>
                    		
                            
                            
                          	  </ul>
                            
                            </li>
                    		<li ><a href="#" >VOCATIONAL</a>
                            
                            		<ul>	
                    		<li><a href="bca.php">BCA</a></li>
                    		<li><a href="bba.php">BBA</a></li>
                    		<li><a href="be.php"> BE</a></li>
                            
                    		<li><a href="bteck.php">B-TECK</a></li>
                    		<li><a href="imd.php">IMD</a></li>
                    		<li><a href="cnd.php">CND </a></li>
                            		</ul>
                            </li>
                    		<li><a href="under_graduate.php">UNDER GRADUATE</a>
                            
                            		<ul>
                            <li><a href="#">Science Departments</a>
									<ul>
										
                    		<li><a href="maths.php">MATHEMATICS</a></li>
                    		<li><a href="chemistry.php">CHEMISTRY</a></li>
                    		<li><a href="physics.php"> PHYSICS</a></li>
                            
                    		<li><a href="botany.php">BOTANY</a></li>
                    		<li><a href="zoology.php">ZOOLOGY</a></li>
										</ul>
							</li>
                    		<li><a href="#"> Arts Departments</a>
									
										<ul>
										
                    		<li><a href="histry.php">HISTRY</a></li>
                    		<li><a href="geography.php">GEOGRAPHT</a></li>
                    		<li><a href="economics.php"> ECONOMICS</a></li>
                            
                    		<li><a href="hindi.php">HINDI</a></li>
                    		
                    		<li><a href="sanskrit.php">SANSKRIT</a></li>
                    		<li><a href="phylosphy.php">PHYLOSPHY</a></li>
                    		<li><a href="psychlogy.php"> PSYCHLOGY</a></li>
                            <li><a href="urdu.php">URDU</a></li>
							
										</ul>
							
							</li>
                    		<li ><a href="commerce.php" >Commerce Department</a></li>
                    		
                            
                            
                          		  </ul>
                            
                            </li>
                    		<li><a href="#">SERTIFICATE/ADD-ON</a></li>
                    		<li><a href="#"> COMMUNITY COLLEGE</a></li>
                        </ul>




				</div>
				