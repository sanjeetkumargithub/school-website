
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home page School</title>
<link type="text/css" rel="stylesheet" href="css_style/style2.css"/> 
<script  type="text/javascript"src='C:\Users\sanjeetku\Documents\jquery1.js'></script>
	<script >
	</script>
	<style>
	a
	{
		text-decoration:none;
		color:white;
	}
	
	</style>
</head>

<body>
<!--Wrapper start-->
<div id="wrapper"> 
<!--Header start-->
<div id="header">
		<div><img src="image/th (5).jpg" height="150px" width="150px"/>
        
        <h2 class="head"> New College Muzaffarpur, </h2> 
        <h2 style="padding-left:500px; color:white;">NAAC Grade 'A'</h2>
		<h3 style="padding-left:730px;"> <a href="#" style="color:white; text-decoration:none;">Home</a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px; ">Map </a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Alumni</a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Download</a></h3>
        <b style="padding-left:270px; color:white;"> Under B. R. A Bihar Univesity Muzaffarpur </b>
        </div>
						
<!--right content start-->
		
		
	<?php include('includes/right_content2.php');?>	
							
<!--right content End-->

 </div><!--Header End-->
 
 
<!--Menu start-->

<?php include('includes/menu2.php'); ?>
<!--Menu End-->
<!--left content Start-->


<?php include('includes/left_content2.php'); ?>

<!--left content End-->


<!--center content start-->
<?php include('includes/center_content2.php'); ?>

<!--center content end-->

<!--right content start-->

<!--this content is wright in header bar , so top page h4 tage-->

<!--right content End-->
<!--Footer start-->

<div id="footer"> 

		<div id="foot1">

			<h3 style="text-align:left; color:#FFFFFF; padding-left:5px;"> All Rights Reserved with New College,<b style="padding-left:280px;">
			 Design & Developed By:</b> <b id="sanjeet"> Sanjeet Kumar </b></h3>


		</div>


</div><!--Footer End-->
</div>
<!--Wrapper End-->


</body>
</html>