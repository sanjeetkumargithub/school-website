
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home page School</title>
<link type="text/css" rel="stylesheet" href="css_style/style.css"/> 
<script  type="text/javascript"src='C:\Users\sanjeetku\Documents\jquery1.js'></script>
	<script >
	</script>
	<style>
	a
	{
		text-decoration:none;
		color:white;
	}
	
	
	#about{
	
					float:left;
					width:210px;
					height:600px;
					background-color:white;}
		#abo1 	
			ul li{
			both:clear;
			list-style:none;
			width:200px;
			height:30px;
			background:#FF6699;
			padding-top:15px;
			margin-top:3px;
			text-align:left;
			padding-left:10px;
		
			}
			#abo1 ul li a{
			text-decoration:none;
		}
			#abo1 ul li:hover{
			color:#CC3300;
			text-align:center;
			
			background-color:#CC0000;
			font-size:17px;
						width:200px;
			height:30px;
			}
		
							
	
	</style>
</head>

<body>
<!--Wrapper start-->
<div id="wrapper"> 
<!--Header start-->
<div id="header">
		<div><img src="image/th (5).jpg" height="150px" width="150px"/>
        
        <h2 class="head"> New College Muzaffarpur, </h2> 
        <h2 style="padding-left:100px; color:white;">NAAC Grade 'A'</h2>
		<h3 style="padding-left:730px;"> <a href="index.php" style="color:white; text-decoration:none;">Home</a>
		<a href="http://www.mapsofindia.com/maps/bihar/districts/muzaffarpur.htm" style="color:white; text-decoration:none;padding-left:7px; ">Map </a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Alumni</a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Download</a></h3>
        <b style="padding-left:0px; color:white;"> Under B. R. A Bihar Univesity Muzaffarpur </b>
        </div>
						

 </div><!--Header End-->
 
 
<!--Menu start-->

<?php include('menu.php'); ?>
<!--Menu End-->

<!--left content tage-->
<div id="about">
				<div id="abo1"> 
						<ul> 
                        		<li><a href="iquac.php">IQUAC</a></li>
                    		<li><a href="sale_purchase.php"> SALE PURCHASE COMMITEE</a></li>
                    		<li ><a href="building.php" >BUILDING DEVELOPMENT</a></li>
                    		<li><a href="commitee.php">COMMITEE</a></li>
                    		<li><a href="ad_commite.php">ADMISSION COMMITEE</a></li>
                    		<li><a href="vocational_edu.php"> VOCATIONAL EDUCATION</a></li>
                    		<li><a href="advisory.php">ADVISORY COMMITEE</a></li>              
                    		<li><a href="exetension.php">EXETENSION ACTIVITIES CELL</a></li>
                            
                    		<li><a href="research_commitee.php">RESEARCH COMMITEE</a></li>
                    		<li><a href="library_advisory.php"> LIBRARY ADVISORY COMMITEE</a></li>
                    		<li><a href="career.php">CAREER & COUNSELLING CELL</a></li>              
                    		<li><a href="rti_com.php">RTI COMMITEE</a></li>
                            
                    		<li><a href="proctorial.php">PROCTORIAL BOARD</a></li>                        </ul>




				</div>
</div>
<!--left content tage-->

<div style="width:790px;height:700px; float:left;">
		<h3 style="background:#999999; text-decoration:underline; color:#CC0000;  width:790px; text-align:left;height:40px;padding-top:10px;">				 		COMMITEE</h3>
			<div style=" border:3px solid #000000; width:785px;height:645px; "> 


			
			
				Vision

  Personality Development and empowerment of women through motivation, dedication and value based education to enable them to lead a purposeful life.

	</div>
</div>

<!--center tage start-->



<!-- content tage end-->




<!--Footer start-->

<div id="footer"> 

		<div id="foot1">

			<h3 style="text-align:left; color:#FFFFFF; padding-left:5px;"> All Rights Reserved with New College,<b style="padding-left:280px;">
			 Design & Developed By:</b> <b id="sanjeet"> Sanjeet Kumar </b></h3>


		</div>


</div><!--Footer End-->
</div>
<!--Wrapper End-->


</body>
</html>