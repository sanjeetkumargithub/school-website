
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home page School</title>
<link type="text/css" rel="stylesheet" href="css_style/style.css"/> 
<script  type="text/javascript"src='C:\Users\sanjeetku\Documents\jquery1.js'></script>
	<script >
	</script>
	<style>
	a
	{
		text-decoration:none;
		color:white;
	}
	
	
	#about{
	
					float:left;
					width:210px;
					height:800px;
					background-color:white;}
		#abo1 	
			ul li{
			both:clear;
			list-style:none;
			width:200px;
			height:30px;
			background:#FF6699;
			padding-top:15px;
			margin-top:3px;
			text-align:left;
			padding-left:10px;
		
			}
			#abo1 ul li a{
			text-decoration:none;
		}
			#abo1 ul li:hover{
			color:#CC3300;
			text-align:center;
			
			background-color:#CC0000;
			font-size:17px;
						width:200px;
			height:30px;
			}
		
							
	
	</style>
</head>

<body>
<!--Wrapper start-->
<div id="wrapper"> 
<!--Header start-->
<div id="header">
		<div><img src="image/th (5).jpg" height="150px" width="150px"/>
        
        <h2 class="head"> New College Muzaffarpur, </h2> 
        <h2 style="padding-left:100px; color:white;">NAAC Grade 'A'</h2>
		<h3 style="padding-left:730px;"> <a href="index.php" style="color:white; text-decoration:none;">Home</a>
		<a href="http://www.mapsofindia.com/maps/bihar/districts/muzaffarpur.htm" style="color:white; text-decoration:none;padding-left:7px; ">Map </a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Alumni</a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Download</a></h3>
        <b style="padding-left:0px; color:white;"> Under B. R. A Bihar Univesity Muzaffarpur </b>
        </div>
						

 </div><!--Header End-->
 
 
<!--Menu start-->

<?php include('menu.php'); ?>
<!--Menu End-->

<!--left content tage-->
<div id="about">
				<div id="abo1"> 
						<ul> 
                        	<li><a href="library.php">LIBRARY</a></li>
                    		<li><a href="sports.php"> SPORTS</a></li>
                    		<li ><a href="remedial.php" >REMEDIAL COACHING</a></li>
                    		<li><a href="intry.php">INTRY IN SERVICES</a></li>
                    		<li><a href="itinfra.php">IT INFRA STRUCTURE</a></li>
                    		<li><a href="canteen.php"> CANTEEN</a></li>
                    		<li><a href="#">COMMON ROOM</a></li>              
                        </ul>




				</div>
</div>
<!--left content tage-->

<div style="width:790px;height:800px; float:left;">
		<h3 style="background:#999999; text-decoration:underline; color:#CC0000;  width:790px; text-align:left;height:40px;padding-top:10px;">				 		CENTRAL LIBRARY</h3>
			<img src="image/library1.jpg"/ width="790px"height="270px ">
		
			<div style=" border:3px solid #000000; width:785px;height:490px; "> 



The Ramdayalu Singh College library is a gateway to a world of information. The student and staffs have unlimited access to a wealth of information pound in resources like books, magazines, journals, statistics, encyclopedias, annual report and the interactive addition, the library offers specious seating arrangements and a calm ambiance for learning.

There is a Library Committee for the College, which acts as Library Advisory Committee, which also keeps eyes on the functioning of the library. The Committee plans developmental activities of the library including library expansion, purchase of new books and periodicals and library reforms.

There is a separate Library building in the college. The Library has open access system. All students and staff have library access cards, ensures the smooth issue and return of books. For quick access of books, each book is indexed under Broad, Narrow and Related Terms in addition to its Author and Title and Publisher and Year of publication. The library is well equipped.

Personal possessions, like bags and books are to be deposited at the counter at the entry, User identity cards with bar codes are issued to every member. Library staffs are well trained and sit at entry and exit points to keep a watch.

 

Library has computer which is connected to broad band connection. More computers are in process to purchase and installed in the library.
<hr />
Opening Hours:	10 AM to 04 PM on Working days.
<hr/>
10 AM to 04 PM	on Examination days.<hr/>
Average number of faculty visiting the library day:	30<hr/>
Average number of students visiting the library day :	150<hr/>
Number of journals subscribed to the institution:	11
The has an open access system.
Books	44006<hr/>
Text books	51729<hr/>
Reference books	1465<hr/>
Magazines	15<hr/>
Indian journals	11
E-resources CD/DVD	25<hr/>
Book Bank:	Yes
Braille Materials:	Yes
Material for Competitive Examination :	Yes<hr/>
Total Carpet Area of the Library :	10000 sqft.
Seating capacity of the library :	130<hr/>
Average No. of books issued/returned per day:	40<hr/>
Ratio of Library Books to the No. of students in rolled :	21:01
	</div>
</div>

<!--center tage start-->



<!-- content tage end-->




<!--Footer start-->

<div id="footer"> 

		<div id="foot1">

			<h3 style="text-align:left; color:#FFFFFF; padding-left:5px;"> All Rights Reserved with New College,<b style="padding-left:280px;">
			 Design & Developed By:</b> <b id="sanjeet"> Sanjeet Kumar </b></h3>


		</div>


</div><!--Footer End-->
</div>
<!--Wrapper End-->


</body>
</html>