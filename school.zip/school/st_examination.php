
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home page School</title>
<link type="text/css" rel="stylesheet" href="css_style/style.css"/> 
<script  type="text/javascript"src='C:\Users\sanjeetku\Documents\jquery1.js'></script>
	<script >
	</script>
	<style>
	a
	{
		text-decoration:none;
		color:white;
	}
	#about{
	
					float:left;
					width:210px;
					height:750px;
					background-color:white;}
		#abo1 	
			ul li{
			both:clear;
			list-style:none;
			width:200px;
			height:30px;
			background:#FF6699;
			padding-top:15px;
			margin-top:3px;
			text-align:left;
			padding-left:10px;
		
			}
			#abo1 ul li a{
			text-decoration:none;
		}
			#abo1 ul li:hover{
			color:#CC3300;
			text-align:center;
			
			background-color:#CC0000;
			font-size:17px;
						width:200px;
			height:30px;
			}
		
	
	</style>
</head>

<body>
<!--Wrapper start-->
<div id="wrapper"> 
<!--Header start-->
<div id="header">
		<div><img src="image/th (5).jpg" height="150px" width="150px"/>
        
        <h2 class="head"> New College Muzaffarpur, </h2> 
        <h2 style="padding-left:100px; color:white;">NAAC Grade 'A'</h2>
		<h3 style="padding-left:730px;"> <a href="index.php" style="color:white; text-decoration:none;">Home</a>
		<a href="http://www.mapsofindia.com/maps/bihar/districts/muzaffarpur.htm" style="color:white; text-decoration:none;padding-left:7px; ">Map </a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Alumni</a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Download</a></h3>
        <b style="padding-left:0px; color:white;"> Under B. R. A Bihar Univesity Muzaffarpur </b>
        </div>
						
<!--right content start-->
		
		
	<?php include('right_content.php');?>	
							
<!--right content End-->

 </div><!--Header End-->
 
 
<!--Menu start-->


<div id="menu"> 
	<div id="menu_fir" >	
    		
                    
                    
                    <ul>
                    <li><a href="#">ABOUT US</a>
                    	<ul> 
                        	<li><a href="about.php">ABOUT THE SCHOOL</a></li>
                    		<li><a href="principal.php"> PRINCIPAL'S DESC</a></li>
                    		<li ><a href="history.php" >HISTORY</a> &nbsp; &nbsp;  </li>
                    		<li><a href="vision.php">VISION</a>  &nbsp; &nbsp; </li>
                    		<li><a href="mission.php">MISSION</a></li>
                        </ul>
                    
                    </li>
					
                    <li ><a href="#" >STUDENTS ZONE</a>
                    <ul> 
                        	<li><a href="st_admission.php">ADMISSION</a></li>
                    		<li><a href="st_exam.php"> EXAMINATION</a></li>
                    		<li ><a href="st_result.php" >RESULT</a></li>
							<li ><a href="st_activites.php" >STUDENT ACTIVITES</a></li>
                    		<li><a href="st_placement.php">PLACEMENT</a></li>
                        </ul>
                    </li>
							
                    <li><a href="#">ACEDMIC</a>
                    	<ul> 
                        	<li><a href="#">TEACHING STAFE</a></li>
                    		<li><a href="#"> RESEARCH PROJECTS</a></li>
                    		<li ><a href="#" >RESEARCH GUIDANCE</a></li>
                    		<li><a href="#">NON TEACHING STAFE</a></li>
                        </ul>
                    </li>
					
				</ul>	
				<!--second menu-->	
					
		<div id="menu_fir2">
					
					<ul>
					
							 <li><a href="#">ASSOCIATION</a>
                    	<ul> 
                        	<li><a href="#">IQUAC</a></li>
                    		<li><a href="#"> SALE PURCHASE COMMITEE</a></li>
                    		<li ><a href="#" >BUILDING DEVELOPMENT</a></li>
                    		<li><a href="#">COMMITEE</a></li>
                    		<li><a href="#">ADMISSION COMMITEE</a></li>
                    		<li><a href="#"> VOCATIONAL EDUCATION</a></li>
                    		<li><a href="#">ADVISORY COMMITEE</a></li>              
                    		<li><a href="#">EXETENSION ACTIVITIES CELL</a></li>
                            
                    		<li><a href="#">RESEARCH COMMITEE</a></li>
                    		<li><a href="#"> LIBRARY ADVISORY COMMITEE</a></li>
                    		<li><a href="#">CAREER & COUNSELLING CELL</a></li>              
                    		<li><a href="#">RTI COMMITEE</a></li>
                            
                    		<li><a href="#">PROCTORIAL BOARD</a></li>
                        </ul>
                    </li>
                   
					</ul>
		</div>
	<div id="menu_fir1" >	
    		
                    
                    
                    <ul>	
					
                    <li><a href="#">FACILITES</a>
                    
                    	<ul> 
                        	<li><a href="library.php">LIBRARY</a></li>
                    		<li><a href="sports.php"> SPORTS</a></li>
                    		<li ><a href="remedial.php" >REMEDIAL COACHING</a></li>
                    		<li><a href="intry.php">INTRY IN SERVICES</a></li>
                    		<li><a href="itinfra.php">IT INFRA STRUCTURE</a></li>
                    		<li><a href="canteen.php"> CANTEEN</a></li>
                    		<li><a href="#">COMMON ROOM</a></li>              
                        </ul>
                    </li>
                    
                    <li><a href="#"> COURSE</a>
                    	 <ul>   
                    		<li><a href="#"> POST GRADUATE</a></li>
                    		<li ><a href="#" >VOCATIONAL</a></li>
                    		<li><a href="#">SELF FINANCE</a></li>
                    		<li><a href="#">SERTIFICATE/ADD-ON</a></li>
                    		<li><a href="#"> COMMUNITY COLLEGE</a></li>
                        </ul>
                    </li>
                    <li><a href="galary.php"> GALERY</a>
                    	
                    </li>
                    <li><a href="tender.php">TENDER</a>
                    
                    </li>              
                    <li><a href="contectus.php">CONTACT US</a></li>
                     
                </ul> 
    </div>

</div>

<!--Menu End-->

<!--left content tage-->
<div id="about">
				<div id="abo1"> 
						<ul> 
                        	<li><a href="st_admission.php">ADMISSION</a></li>
                    		<li><a href="st_exam.php"> EXAMINATION</a></li>
                    		<li ><a href="st_result.php" >RESULT</a></li>
							<li ><a href="st_activites.php" >STUDENT ACTIVITES</a></li>
                    		<li><a href="st_placement.php">PLACEMENT</a></li>
                        </ul>




				</div>
				<DIV style="padding-top:15px; height:40px;background-color:#FF00CC;color:#FF9900; margin-top:50px;">	STUDENT RESULTS </DIV>
</div>
<!--left content tage-->


<!--right content start-->

<!--this content is wright in header bar , so top page h4 tage-->

<!--right content End-->
<!--Footer start-->

<div id="footer"> 

		<div id="foot1">

			<h3 style="text-align:left; color:#FFFFFF; padding-left:5px;"> All Rights Reserved with New College,<b style="padding-left:280px;">
			 Design & Developed By:</b> <b id="sanjeet"> Sanjeet Kumar </b></h3>


		</div>


</div><!--Footer End-->
</div>
<!--Wrapper End-->


</body>
</html>