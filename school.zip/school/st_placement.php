
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home page School</title>
<link type="text/css" rel="stylesheet" href="css_style/style.css"/> 
<script  type="text/javascript"src='C:\Users\sanjeetku\Documents\jquery1.js'></script>
	<script >
	</script>
	<style>
	a
	{
		text-decoration:none;
		color:white;
	}
	#about{
	
					float:left;
					width:210px;
					height:750px;
					background-color:white;}
		#abo1 	
			ul li{
			both:clear;
			list-style:none;
			width:200px;
			height:30px;
			background:#FF6699;
			padding-top:15px;
			margin-top:3px;
			text-align:left;
			padding-left:10px;
		
			}
			#abo1 ul li a{
			text-decoration:none;
		}
			#abo1 ul li:hover{
			color:#CC3300;
			text-align:center;
			
			background-color:#CC0000;
			font-size:17px;
						width:200px;
			height:30px;
			}
		
	
	</style>
</head>

<body>
<!--Wrapper start-->
<div id="wrapper"> 
<!--Header start-->
<div id="header">
		<div><img src="image/th (5).jpg" height="150px" width="150px"/>
        
        <h2 class="head"> New College Muzaffarpur, </h2> 
        <h2 style="padding-left:100px; color:white;">NAAC Grade 'A'</h2>
		<h3 style="padding-left:730px;"> <a href="index.php" style="color:white; text-decoration:none;">Home</a>
		<a href="http://www.mapsofindia.com/maps/bihar/districts/muzaffarpur.htm" style="color:white; text-decoration:none;padding-left:7px; ">Map </a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Alumni</a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Download</a></h3>
        <b style="padding-left:0px; color:white;"> Under B. R. A Bihar Univesity Muzaffarpur </b>
        </div>
						
<!--right content start-->
		
		
	<?php include('right_content.php');?>	
							
<!--right content End-->

 </div><!--Header End-->
 
 
<!--Menu start-->

<?php
include('menu.php');
?>
<!--Menu End-->

<!--left content tage-->
<div id="about">
				<div id="abo1"> 
						<ul> 
                        	<li><a href="st_admission.php">ADMISSION</a></li>
                    		<li><a href="st_exam.php"> EXAMINATION</a></li>
                    		<li ><a href="st_result.php" >RESULT</a></li>
							<li ><a href="st_activites.php" >STUDENT ACTIVITES</a></li>
                    		<li><a href="st_placement.php">PLACEMENT</a></li>
                        </ul>




				</div>
				<DIV style="padding-top:15px; height:40px;background-color:#FF00CC;color:#FF9900; margin-top:50px;">	STUDENT RESULTS </DIV>
</div>
<!--left content tage-->

<!--left content tage-->


<div id="center_content1">
<DIV style="padding-top:15px; height:40px;background-color:#FFCC99; color:white; margin-top:0px;">	STUDENT PLACEMENT</DIV>


Vet Disability Benefits | Military.com
Ad · Military.com/​VetDisabilityBenefits
Learn about your Veteran Disability Benefits at Military.com
Refinance With a VA Loan
Check Out the 2015 Pay Charts
Get Connected With Veteran Benefits
Your VA Loan Benefits
Veteran Benefits Made Easy
VA Loan Approved Lenders
Get Disability Benefits - Over 50 & Need Disability Benefits?
Ad · DisabilityBenefitsHome.com
Over 50 & Need Disability Benefits? See if You Qualify Today!
Can I Get Disability?  Free Case Evaluation
Director Student Disability Jobs - One Search. All Jobs.
Teaching | Disabled Students' Program
dsp.berkeley.edu/faculty/resources/teaching
General Suggestions on Teaching Students with Disabilities. Faculty control the curriculum in the classroom, and determine how curriculum is taught, and how it is ...
College Resources for Students with Disabilities
www.bestcolleges.com/resources/disabled-student
College students with disabilities will find that many campuses address accessibility, accommodation, and assistive technology for a diverse range of needs.
Students with Disabilities - New York University
www.nyu.edu/.../communities-and-groups/students-with-disabilities.html
New York University is committed to providing equal educational opportunity and participation for students with disabilities. It is the University’s policy that no ...
Services for Students with Disabilities
https://www.fscj.edu/.../services-for-students-with-disabilities
The Office of Services for Students with Disabilities implements and coordinates reasonable accommodations and disability-related services.
Students with Disabilities | Psychological and Counseling ...
www.unh.edu/pacs/students-disabilities
According to the Americans with Disabilities Act (ADA), a person with a disability is defined as someone with a mental, physical, or emotional challenge that ...
Successful Strategies for Teaching Students with Learning ...
https://ldaamerica.org/successful-strategies-for-teaching-students...
Successful Strategies for Teaching Students with ... for teaching students with a mild disability, ... for Teaching Students with Learning Disabilities,” the ...
Grants for the Disabled | USAGrantApplications.org
Ad · USAGrantApplications.org
Change is on its way in 2017 - 1000's of Grant Applications.
Vet Disability Benefits | Military.com
Ad · Military.com/​VetDisabilityBenefits
Learn about your Veteran Disability Benefits at Military.com
Refinance With a VA Loan
Check Out the 2015 Pay Charts
Get Connected With Veteran Benefits
Your VA Loan Benefits
Veteran Benefits Made Easy
VA Loan Approved Lenders
Get Disability Benefits - Over 50 & Need Disability Benefits?
Ad · DisabilityBenefitsHome.com
Over 50 & Need Disability Benefits? See if You Qualify Today!
Can I Get Disability?  Free Case Evaluation
Director Student Disability Jobs - One Search. All Jobs.
Ad · indeed.com
One Search. All Jobs. Find Your New Job Today. Indeed™
Searches related tostudent with disability
education for students with disabilit...
classroom strategies for learning dis...
students with disabilities in school
funding for students with disabilities
teaching students with physical disab...
instructional strategies for students...
teachers and students with disabilities
student with disability scholarships
disability discharge
12345Next
Answers
National Bureau for Students with...
National Bureau for Students With Disabilities is a UK charity promoting opportunities for people with any kind of disability in post-16 education,... more
Post Secondary Transition for High...
The Post Secondary Transition For High School Students with Disabilities refers to the ordinance that every public school district in the United States... more
College Students with Intellectual...
with disabilities including those with ID (Butler, Sheppard-Jones, Whaley, Harrison & Osness, 2015). Students that attend a PSE program are more likely... more
Student With Disability News
Explorations Program Gives High School Students with Disabilities a...
Business: Employment - Aug 7
I am loving it! I’m learning so many new things,” says Trey. "I’ve always wanted to do paleontology, and now I got to do it. Old Town, FL (PRWEB) August 07, 2017 A new program is helping high... more
Minority, disabled students punished more, report says
Phoenix - Local - 8 hrs ago
A report by the ACLU of Arizona confirms that some schools punish minority students and students with disabilities more than their white counterparts. Ashleigh Wilson/azcentral.com Wochit more
University of Pennsylvania program helps students with disabilities
Philadelphia Public School... - Aug 4
Joselito "Josie" Torres is 19 years old, but until recently he had never made a purchase at a store by himself. He never rode the subway, nor had he bought a ticket to a museum on his own. But when... more
Search the Web
student with 
	</div>
	


<!--center tage start-->

<!--right content start-->

<!--this content is wright in header bar , so top page h4 tage-->

<!--right content End-->
<!--Footer start-->

<div id="footer"> 

		<div id="foot1">

			<h3 style="text-align:left; color:#FFFFFF; padding-left:5px;"> All Rights Reserved with New College,<b style="padding-left:280px;">
			 Design & Developed By:</b> <b id="sanjeet"> Sanjeet Kumar </b></h3>


		</div>


</div><!--Footer End-->
</div>
<!--Wrapper End-->


</body>
</html>