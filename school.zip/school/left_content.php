
<div id="left_content">
<h2 style="background:#990000;height:38px; text-align:center; color:#FFFF99;padding-top:14px;"> QUICK LINK</h2>
			<ul> 
                        	<li><a href="#">APPLY ONLINE</a> &nbsp; 
                    		<li><a href="#"> INFLIBNET ONLINE</a></li>
                    		<li ><a href="#" >LIBRARY OPAC</a></li>
                    		<li><a href="#">FEEDBACK</a></li>
                    		<li><a href="#">B.R.A.B.U</a></li>
                    		<li><a href="#"> UCG</a> </li>
                    
                        </ul>
						
<h3 style="background:#990000;height:38px; text-align:center; color:#FFFF99;padding-top:14px;"> HERITAGE LAVUE</h3>

<div id="left_content_last">
<ul > 
                        	<li><a href="#">Planetarium</a></li>
                    		<li><a href="#"> Observatory</a></li>         
                    		<li><a href="#">Ghandhkoop</a></li>
                        </ul>
						</div>
							<h3 style="background:#990000;height:28px; text-align:center; color:#FFFF99;padding-top:5px;"> PRINCIPAL'S DESK</h3>
							
			<div style="border:4px  groove #FF0099; color:#FF0066;"><img src="image/principal.jpg"/ width="202px"height="180px "> <br/><h2 color="red" align="center">D.K.SINGH</h2>
				</div>	
				
				<div style="border:4px  groove #FF0099; color: orange;"><img src="image/book.jpg"/ width="202px"height="92px "><br/><h3 " align="center">LIBRARY</h3>
				</div>						
</div>	

</div>
