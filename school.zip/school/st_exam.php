
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home page School</title>
<link type="text/css" rel="stylesheet" href="css_style/style.css"/> 
<script  type="text/javascript"src='C:\Users\sanjeetku\Documents\jquery1.js'></script>
	<script >
	</script>
	<style>
	a
	{
		text-decoration:none;
		color:white;
	}
	#about{
	
					float:left;
					width:210px;
					height:750px;
					background-color:white;}
		#abo1 	
			ul li{
			both:clear;
			list-style:none;
			width:200px;
			height:30px;
			background:#FF6699;
			padding-top:15px;
			margin-top:3px;
			text-align:left;
			padding-left:10px;
		
			}
			#abo1 ul li a{
			text-decoration:none;
		}
			#abo1 ul li:hover{
			color:#CC3300;
			text-align:center;
			
			background-color:#CC0000;
			font-size:17px;
						width:200px;
			height:30px;
			}
		
	
	</style>
</head>

<body>
<!--Wrapper start-->
<div id="wrapper"> 
<!--Header start-->
<div id="header">
		<div><img src="image/th (5).jpg" height="150px" width="150px"/>
        
        <h2 class="head"> New College Muzaffarpur, </h2> 
        <h2 style="padding-left:100px; color:white;">NAAC Grade 'A'</h2>
		<h3 style="padding-left:730px;"> <a href="index.php" style="color:white; text-decoration:none;">Home</a>
		<a href="http://www.mapsofindia.com/maps/bihar/districts/muzaffarpur.htm" style="color:white; text-decoration:none;padding-left:7px; ">Map </a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Alumni</a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Download</a></h3>
        <b style="padding-left:0px; color:white;"> Under B. R. A Bihar Univesity Muzaffarpur </b>
        </div>
						
<!--right content start-->
		
		
	<?php include('right_content.php');?>	
							
<!--right content End-->

 </div><!--Header End-->
 
 
<!--Menu start-->

<?php
include('menu.php');

?>
<!--Menu End-->

<!--left content tage-->
<div id="about">
				<div id="abo1"> 
						<ul> 
                        	<li><a href="st_admission.php">ADMISSION</a></li>
                    		<li><a href="st_exam.php"> EXAMINATION</a></li>
                    		<li ><a href="st_result.php" >RESULT</a></li>
							<li ><a href="st_activites.php" >STUDENT ACTIVITES</a></li>
                    		<li><a href="st_placement.php">PLACEMENT</a></li>
                        </ul>




				</div>
				<DIV style="padding-top:15px; height:40px;background-color:#FF00CC;color:#FF9900; margin-top:50px;">	STUDENT EXAMINATION </DIV>
</div>
<!--left content tage-->
<!--center content start-->


<div id="center_content1">
<DIV style="padding-top:15px; height:40px;background-color:#FFCC99; color:white; margin-top:0px;">	STUDENT EXAMINATION </DIV>


Live CE Exit Planning
Programs
Live CE Webinar – Business Owner Exit Planning on 08/08/17
Exit planning is the creation and execution of a strategy allowing owners to exit their businesses on their terms and conditions. This session will provide the background for the wave of small business transfers that are expected to occur as a result of the baby boom generation continuing its
Read MoreHow the Best Financial Plan Can be Waylaid by Negative Money Behavior
Programs
Live CE Webinar – How the Best Financial Plan Can be Waylaid by Negative Money Behavior on 06/13/17
Everyone knows to buy assets low and sell them high, but due to loss aversion this often is not the case. Investors, on average, lose an estimated 30% of their possible returns due to loss aversion and other behavioral biases. Financial planners, without needing a degree in psychology, can
Read MoreCFP Code of Ethics Banner
Programs
Live Ethics CE (aka. Code of Ethics) Presentation
This course satisfies CFP Board’s 2-hour Ethics continuing education requirement. Tuesday May 9, 2017 From 1PM until 3PM (MDT) By Professors Jim Pasztor and David Mannaioni
Read MoreLive CE Best Practices DOL
Programs
Live CE Webinar – Best Practices for Complying with the New DOL Fiduciary Standard on 04/11/17
The Department of Labor’s fiduciary standard became law on April 10, 2016. This webinar will help you gain a better understanding of the requirements of the new DOL fiduciary standard and how it will impact advisers, clients, and the industry as a whole. Detailed discussion will include the latest
Read MoreUses of Home Equity in Retirement Plans
Programs
Live CE Webinar – Uses of Home Equity in Retirement Plans on 03/14/17
Join us for a Live CE Webinar Uses of Home Equity in Retirement Plans March, 14th 2017 at 4:00PM (EST) Presented by Professor Sam Van Why, MA, CLU, ChFC For many Americans who are approaching retirement, or are already in retirement, the equity in their home may well be
Read More
Posts navigation



</div>

<!--center content end-->


<!--right content start-->

<!--this content is wright in header bar , so top page h4 tage-->

<!--right content End-->
<!--Footer start-->

<div id="footer"> 

		<div id="foot1">

			<h3 style="text-align:left; color:#FFFFFF; padding-left:5px;"> All Rights Reserved with New College,<b style="padding-left:280px;">
			 Design & Developed By:</b> <b id="sanjeet"> Sanjeet Kumar </b></h3>


		</div>


</div><!--Footer End-->
</div>
<!--Wrapper End-->


</body>
</html>