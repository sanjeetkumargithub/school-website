


<?php
session_start();
if(isset($_POST['submit'])){

$name=$_POST['name'];
$email=$_POST['email'];
$subject=$_POST['subject'];
$messages=$_POST['messages'];

include('includes/db.php');
$insert_q="insert into contectus  (name, email,subject,messages)values('$name','$email','$subject','$messages')";
$result=mysqli_query($con,$insert_q);

if($result){
$_SESSION['email']=$email;
echo"<script>alert('Your Account has been Complited,Thanks $name')</script>";

echo"<script>window.open('index.php','_self')</script>";}




$to="newcollegemuz23@gmail.com";
$sub="Thanks".$_POST['name'];
$message="Welcome to in Your my college,";
$from=$_POST['email'];
$result=mail($to,$sub,$message,$from);
if($result){
echo"<script>alert('Welcome to send Your email Message') </script>";
}
else{echo"<script>alert('Not send Your email Message') </script>";}

}
?> 


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home page School</title>
<link type="text/css" rel="stylesheet" href="css_style/style.css"/> 
<script  type="text/javascript"src='C:\Users\sanjeetku\Documents\jquery1.js'></script>
	<script >
	</script>
	<style>
	a
	{
		text-decoration:none;
		color:white;
	}
	
	
	#about{
	
					float:left;
					width:210px;
					height:600px;
					background-color:white;}
		#abo1 	
			ul li{
			both:clear;
			list-style:none;
			width:200px;
			height:30px;
			background:#FF6699;
			padding-top:15px;
			margin-top:3px;
			text-align:left;
			padding-left:10px;
		
			}
			#abo1 ul li a{
			text-decoration:none;
		}
			#abo1 ul li:hover{
			color:#CC3300;
			text-align:center;
			
			background-color:#CC0000;
			font-size:17px;
						width:200px;
			height:30px;
			}
		
							
	
	</style>
</head>

<body>
<!--Wrapper start-->
<div id="wrapper"> 
<!--Header start-->
<div id="header">
		<div><img src="image/th (5).jpg" height="150px" width="150px"/>
        
        <h2 class="head"> New College Muzaffarpur, </h2> 
        <h2 style="padding-left:100px; color:white;">NAAC Grade 'A'</h2>
		<h3 style="padding-left:730px;"> <a href="index.php" style="color:white; text-decoration:none;">Home</a>
		<a href="http://www.mapsofindia.com/maps/bihar/districts/muzaffarpur.htm" style="color:white; text-decoration:none;padding-left:7px; ">Map </a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Alumni</a>
		<a href="#" style="color:white; text-decoration:none;padding-left:7px;" >Download</a></h3>
        <b style="padding-left:0px; color:white;"> Under B. R. A Bihar Univesity Muzaffarpur </b>
        </div>
						

 </div><!--Header End-->
 
 
<!--Menu start-->

<?php include('menu.php'); ?>
<!--Menu End-->

<!--left content tage-->
<div id="about">
				<div id="abo1"> 
						<ul> 
                        	
          					<li><a href="contectus.php"><img src="image/contact.gif" width="160px" height="125px"/></a></li>
                        </ul>




				</div>
</div>
<!--left content tage-->


<!--center tage start-->

<div style="width:790px;height:600px; float:left; background:#CCCCCC;">
	
					<div style=" border:3px solid #CC0000; width:360px;height:200px; margin:11px; border-radius:15px 15px 0px 0px;  "> 
		
								<div style="background:#CC0000; height:40px; width:auto;"><h2 style="padding:5px; margin-left:-145px; color : white;">	  									CONTECT US</h2> </div>	
								
								
								<div style="text-align:left;padding-top:20px;padding-left:10px;">
									<tr> <th><b >NAME:</b></th> <td><span style="padding-left:90px;">New College Muz </span></td></tr><br/><br />
							
									<tr> <th><b margin>STATE:</b></th> <td><span style="padding-left:90px;"> Bihar</span> </td></tr><br /><br />
									<tr> <th><b>Mb:</b></th> <td><span style="padding-left:115px;"> 9999999999 </span></td></tr><br /><br />
							
									<tr> <th><b>EMAIL:</b> </th> <td><span style="padding-left:85px;"> Newcollege9459@gmail.com</span> </td></tr>
							
									</div>
															
					</div>  
		
						
		
</div>
					<div style=" border:3px solid #CC0000; background:#CC0000;  position:absolute; padding-left:10px;width:360px;height:300px;
								margin-top:65px; margin-left:610px; border-radius:15px ; float:right; "> 
							
						<form action="contectus.php" method="post" >
						<table  ></tr><tr> </tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr>
						<tr  ><td > <input type="text" name="name"  required placeholder="Enter Name" size="40px" height="20px" style="border-radius:20px; text-align:center; size-height:20px;"  /></td> </tr><tr> </tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr>
						<tr><td> <input type="text" name="email" required placeholder="Enter Email" size="40px" style="border-radius:20px; text-align:center; size-height:20px;"  /></td> </tr><tr> </tr></tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr>

						<tr><td> <input type="text" name="subject" required placeholder="Enter Subject" size="40px"style="border-radius:20px; text-align:center; size-height:20px;"  /></td> </tr><tr> </tr></tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr>
												<tr >
						<th align="center" > <b  style="color:white">Enter Messages:</b></th></tr>
						<tr><td ><textarea rows="6" cols="41" name="messages"  style="border-radius:20px; text-align:center; "  > </textarea></td> </tr></tr><tr> </tr><tr> </tr><tr></tr></tr><tr> </tr><tr> </tr><tr></tr> </tr><tr> </tr><tr> </tr><tr></tr>
						<tr><td size="20px"> <input type="submit" name="submit" value="Submit" style=" background-color:#FF0000;border-radius:20px; text-align:center; size-height:20px; color:#FFFFFF; font-size:15px;" />  &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;<input type="reset"  value="Reset" style="border-radius:20px; text-align:center; size-height:20px;font-size:15px; background-color:#FF6600; color:#FFFFFF;" /></td> </tr>
						
						</table>
						</form>
			
					</div>

<!-- content tage end-->




<!--Footer start-->

<div id="footer"> 

		<div id="foot1">

			<h3 style="text-align:left; color:#FFFFFF; padding-left:5px;"> All Rights Reserved with New College,<b style="padding-left:280px;">
			 Design & Developed By:</b> <b id="sanjeet"> Sanjeet Kumar </b></h3>


		</div>


</div><!--Footer End-->
</div>
<!--Wrapper End-->


</body>
</html>
