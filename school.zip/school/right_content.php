	<div  style="  margin-top:78px; margin-left:780px;width:218.5px; height:755px; background-color:#FFFFFF; "> 
			<h5 style=" background-color:#CC3300;height:28px; text-align:center; color:#FFFF99;padding-top:20px; margin-top:-12px; position:absolute; 						     				font-size:15.8px;padding-left:1px;"> IMPORTANT INFORMATION</h5>
					
					
				<div  style="background-color:white; height:250px; border:3px solid #CC66CC; padding-top:50px;text-align:justify;">			
						<marquee direction="up" ><h3 id="news_right"> Graduation  Results on<b class="news_style"> News</b>  2017  And  news 	 			 						Intermediats Results 2017 at This time<b class="news_style"> News</b>   And  Intermediats Results 2017 Uppdeted Time
						 <b class="news_style">
  						News</b>College All information is expose By College principal <b class="news_style"> News</b></h3> </marquee>	
				
				
					<tr > <h2 id="new_m"><a href="morenews.php"  >More...</a></h2></tr>
					
					
					</div>	
					
				<div  id="flage"> <img src="image/flage.jpg" height="140px" width="140px" />	</div>	
					<div id="radhakrishnan"><img src="image/Radhakrishnan, Sarvepalli.jpg"/ width="211px"height="180px "> <br/><h2 color="red" align="center">  Sarvepalli<br/> Radhakrishnan</h2>
				</div>
				<div id="facebook">
				
 
<a href="http://www.facebook.com"><img  src="image/facebook.png"  width='35px' height='35' /> </a>
<a href="http://www.whatapp.com"> <img  src="image/whatsapp.png"  width='35px' height='35' /> </a>
<a href="http://www.google.com">  <img  src="image/google.jpg"   width='35px' height='35'/></a>
<a href="http://www.youtube.com">  <img  src="image/images.jpg"  width='35px' height='35' /></a>
<a href="http://www.twitter.com">  <img  src="image/twitter.png" width='35px' height='35'  /></a>
<a href="http://www.paytm.com">  <img  src="image/paytm.jpg"  width='35px' height='35'  /></a>
 
			</div>		
	</div>
